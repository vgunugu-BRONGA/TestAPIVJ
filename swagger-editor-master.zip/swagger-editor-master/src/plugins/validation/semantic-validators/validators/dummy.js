/* eslint-disable */
export function validate({ jsSpec }) {
  let errors = []
  let warnings = []

  // do stuff

  return { errors, warnings }
}
